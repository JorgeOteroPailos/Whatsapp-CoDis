package codis.whatsapp.Aplicacion;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;

public interface IServidor extends Remote {
    String iniciar_sesion(String nombre, String contrasena) throws RemoteException;
    void registrarse(String nombre, String contrasena) throws RemoteException;
    void crear_solicitud(String solicitante, String solicitado) throws RemoteException;
    void aceptar_solicitud(String solicitante, String solicitao) throws RemoteException;
    void rechazar_solicitud(String solicitante, String solicitado) throws RemoteException;
    ArrayList<String> mostrar_solicitudes(String usuario) throws RemoteException;
    void borrar_amistad(String usuario, String amistad) throws RemoteException;
    ArrayList<Usuario> obtener_lista_amigos(Usuario usuario) throws RemoteException;
    void cerrar_sesion(String nombre) throws RemoteException;
}
