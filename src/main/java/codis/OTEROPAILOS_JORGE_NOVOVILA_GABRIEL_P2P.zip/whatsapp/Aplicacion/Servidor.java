package codis.whatsapp.Aplicacion;

import codis.whatsapp.BD.DAOUsuarios;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.*;
import java.util.ArrayList;

public class Servidor extends UnicastRemoteObject implements IServidor {
    DAOUsuarios daoUsuarios;
    Connection conn;
    private static final String URL = "jdbc:postgresql://localhost:5432/postgres";

    public Servidor() throws RemoteException {
        super();
        try {
            // Conexión a la base de datos
            conn=DriverManager.getConnection(URL, "postgres", "Ickki2p2??");
            System.out.println("Conexión exitosa a la base de datos.");

        } catch (SQLException e) {
            System.out.println("Error al conectar: " + e.getMessage());
            java.lang.System.exit(-1);
        }
        daoUsuarios=new DAOUsuarios(conn);
    }

    public String iniciar_sesion(String nombre, String contrasena) throws RemoteException {
        return daoUsuarios.iniciarSesion(nombre, contrasena);
    }

    public void registrarse(String nombre, String contrasena) throws RemoteException {
        daoUsuarios.registrarse(nombre, contrasena);
    }

    public void crear_solicitud(String solicitante, String solicitado) throws RemoteException {
        daoUsuarios.crear_solicitud(solicitante, solicitado);
    }

    public void aceptar_solicitud(String solicitante, String solicitado) throws RemoteException {
        daoUsuarios.aceptar_solicitud(solicitante, solicitado);
    }
    public void rechazar_solicitud(String solicitante, String solicitado) throws RemoteException {
        daoUsuarios.rechazar_solicitud(solicitante, solicitado);
    }

    public ArrayList<String> mostrar_solicitudes(String usuario) throws RemoteException {
        return daoUsuarios.mostrar_solicitudes(usuario);
    }

    public void borrar_amistad(String usuario, String amistad) throws RemoteException {
        daoUsuarios.borrar_amistad(usuario, amistad);
    }

    public ArrayList<Usuario> obtener_lista_amigos(Usuario usuario) throws RemoteException {
        return daoUsuarios.obtener_lista_amigos(usuario);
    }

    public void cerrar_sesion(String nombre) throws RemoteException {
        daoUsuarios.cerrar_sesion(nombre);
    }
}