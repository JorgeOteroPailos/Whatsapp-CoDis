package codis.whatsapp.Aplicacion;

import codis.whatsapp.GUI.Popup;
import javafx.scene.control.Alert;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

import static codis.whatsapp.Aplicacion.MainServidor.startRegistry;

public class Cliente implements ICliente{
    private final Usuario user;
    private final String IP;
    private final int puerto;
    private ArrayList<ICliente> amigosEnLinea;
    private IServidor servidor;
    private String codigoSesion;

    public void enviar(String m, Usuario remitente, String codigo){
        //TODO

    }


    public Usuario getUser(){
        return user;
    }

    public Cliente(Usuario user, String IP, int puerto) throws RemoteException {
        //super();
        this.user=user;
        this.IP=IP;
        this.puerto=puerto;
        //publicarse();
        //TODO
    }

    public ArrayList<ICliente> getAmigosEnLinea() {
        return amigosEnLinea;
    }

    public void setAmigosEnLinea(ArrayList<ICliente> amigosEnLinea) {
        this.amigosEnLinea = amigosEnLinea;
    }

    private void publicarse(){
        try {
            Servidor exportedObj = new Servidor();
            startRegistry(puerto);
            // register the object under the name “some”
            String registryURL = "rmi://"+IP+":" + puerto + "/some";
            Naming.rebind(registryURL, exportedObj);
            System.out.println("Cliente publicado correctamente");
        } catch (Exception e) {
            System.err.println("Remote Exception : " + e);
            Popup.show("Error", "Error al publicar el cliente"+e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    public IServidor getServidor(){
        return servidor;
    }

}
