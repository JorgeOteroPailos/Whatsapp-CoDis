package codis.whatsapp.Aplicacion;

public record Usuario(String nombre) {

}
